package com.problem_statement_2_3;


public class IntegerArray {  
    public static void main(String[] args) {  
            //Initialize array  
            int [] arr = new int [] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, };  
            int sum = 0;  
            double average = 0;
            //Loop through the array to calculate sum of elements  
            for (int i = 0; i < arr.length; i++) {  
               sum = sum + arr[i];  
            }  
            System.out.println("Sum of all the elements of an array: " + sum);
            average = sum / arr.length;
            arr [15] = sum;
            System.out.println("Value stored at index 15 :" +arr[15]);
            System.out.println("Average value of the array elements is : " + average);
            for (int i = 0; i < arr.length; i++)   
            {  
                for (int j = i + 1; j < arr.length; j++)   
                {  
                    if (arr[i] > arr[j])   
                    {  
                        int temp = arr[i];  
                        arr[i] = arr[j];  
                        arr[j] = temp;  
                    }  
                }  
                
            }
            System.out.println("Smallest Number in the array is: "+arr[0]);
            
        }  
    }  